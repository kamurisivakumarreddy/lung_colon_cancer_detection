"""
OnchoAI — Prediction Engine
Loads the trained .keras model once and provides:
  - predict(image_path)  → class, confidence, probabilities
  - gradcam(image_path, pred_index) → heatmap overlay image path
"""
import os
import io
import uuid
import numpy as np
import cv2
from PIL import Image
import logging

logger = logging.getLogger(__name__)

_model = None
_model_loaded = False
_model_error  = None

CLASS_NAMES = ['colon_aca', 'colon_n', 'lung_aca', 'lung_n', 'lung_scc']
CLASS_LABELS = {
    'colon_aca': 'Colon Adenocarcinoma',
    'colon_n':   'Colon Benign Tissue',
    'lung_aca':  'Lung Adenocarcinoma',
    'lung_n':    'Lung Benign Tissue',
    'lung_scc':  'Lung Squamous Cell Carcinoma',
}
IMG_SIZE = (224, 224)

# Grad-CAM target layer (last conv layer before GAP in the multi-branch)
GRADCAM_LAYER = 'multi_densenet_backbone'


def load_model():
    global _model, _model_loaded, _model_error
    if _model_loaded:
        return _model

    from django.conf import settings
    model_path = settings.MODEL_PATH

    if not os.path.exists(model_path):
        _model_error = f"Model file not found at: {model_path}"
        _model_loaded = True
        logger.warning(_model_error)
        return None

    try:
        import tensorflow as tf
        logger.info(f"Loading model from {model_path} ...")
        _model = tf.keras.models.load_model(model_path, compile=False)
        logger.info("Model loaded successfully.")
    except Exception as e:
        _model_error = str(e)
        logger.error(f"Failed to load model: {e}")
        _model = None

    _model_loaded = True
    return _model


def preprocess(image_path):
    img = Image.open(image_path).convert('RGB').resize(IMG_SIZE)
    arr = np.array(img, dtype=np.float32) / 255.0
    return np.expand_dims(arr, 0), img


def predict(image_path):
    """
    Returns dict:
      predicted_class, confidence, probabilities (list of 5 floats 0-1),
      using_real_model (bool)
    """
    model = load_model()

    if model is None:
        # Fallback simulation so the app still works while model downloads
        import random
        probs = [round(random.uniform(0.01, 0.15), 4) for _ in CLASS_NAMES]
        top   = random.randint(0, 4)
        probs[top] = round(random.uniform(0.55, 0.90), 4)
        total = sum(probs)
        probs = [round(p / total, 4) for p in probs]
        return {
            'predicted_class': CLASS_NAMES[top],
            'confidence':      round(probs[top] * 100, 2),
            'probabilities':   probs,
            'using_real_model': False,
            'error': _model_error,
        }

    arr, _ = preprocess(image_path)
    raw    = model.predict(arr, verbose=0)[0]
    probs  = [float(p) for p in raw]
    top    = int(np.argmax(probs))

    return {
        'predicted_class': CLASS_NAMES[top],
        'confidence':      round(probs[top] * 100, 2),
        'probabilities':   probs,
        'using_real_model': True,
        'error': None,
    }


def generate_gradcam(image_path, pred_index, save_dir):
    """
    Generate Grad-CAM heatmap overlay.
    Returns saved filename (relative to MEDIA_ROOT/gradcam/) or None on failure.
    """
    model = load_model()
    if model is None:
        return None

    try:
        import tensorflow as tf

        arr, orig_img = preprocess(image_path)

        # Find last conv layer dynamically if GRADCAM_LAYER not found
        target_layer = None
        for layer in reversed(model.layers):
            if hasattr(layer, 'layers'):           # sub-model (backbone)
                for sub in reversed(layer.layers):
                    if len(sub.output_shape) == 4: # conv output
                        target_layer = sub.name
                        break
            if target_layer:
                break
            if len(layer.output_shape) == 4:
                target_layer = layer.name
                break

        if target_layer is None:
            return None

        # Build grad model
        grad_model = tf.keras.models.Model(
            inputs=model.inputs,
            outputs=[model.get_layer(target_layer).output, model.output]
        )

        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(arr)
            class_channel = predictions[:, pred_index]

        grads        = tape.gradient(class_channel, conv_outputs)
        pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
        conv_out     = conv_outputs[0]
        heatmap      = conv_out @ pooled_grads[..., tf.newaxis]
        heatmap      = tf.squeeze(heatmap).numpy()
        heatmap      = np.maximum(heatmap, 0)
        if heatmap.max() > 0:
            heatmap  = heatmap / heatmap.max()

        # Overlay on original image
        orig_np   = np.array(orig_img)
        heatmap_r = cv2.resize(heatmap, (orig_np.shape[1], orig_np.shape[0]))
        heatmap_c = cv2.applyColorMap(np.uint8(255 * heatmap_r), cv2.COLORMAP_JET)
        heatmap_c = cv2.cvtColor(heatmap_c, cv2.COLOR_BGR2RGB)
        overlay   = cv2.addWeighted(orig_np, 0.55, heatmap_c, 0.45, 0)

        os.makedirs(save_dir, exist_ok=True)
        fname    = f"gradcam_{uuid.uuid4().hex[:10]}.jpg"
        out_path = os.path.join(save_dir, fname)
        Image.fromarray(overlay).save(out_path, quality=92)
        return fname

    except Exception as e:
        logger.error(f"Grad-CAM failed: {e}")
        return None
