from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id',         models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('name',       models.CharField(max_length=100)),
                ('email',      models.EmailField(unique=True)),
                ('password',   models.CharField(max_length=128)),
                ('phone',      models.CharField(blank=True, default='', max_length=20)),
                ('hospital',   models.CharField(blank=True, default='', max_length=200)),
                ('role',       models.CharField(blank=True, default='', max_length=100)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={'db_table': 'app_userprofile'},
        ),
        migrations.CreateModel(
            name='PredictionRecord',
            fields=[
                ('id',              models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('user',            models.ForeignKey(blank=True, null=True,
                                        on_delete=django.db.models.deletion.CASCADE,
                                        related_name='predictions', to='app.userprofile')),
                ('image',           models.ImageField(blank=True, null=True, upload_to='predictions/')),
                ('gradcam',         models.ImageField(blank=True, null=True, upload_to='gradcam/')),
                ('predicted_class', models.CharField(blank=True, choices=[
                                        ('colon_aca','Colon Adenocarcinoma'),
                                        ('colon_n','Colon Benign'),
                                        ('lung_aca','Lung Adenocarcinoma'),
                                        ('lung_n','Lung Benign'),
                                        ('lung_scc','Lung Squamous Cell Carcinoma'),
                                    ], max_length=50)),
                ('confidence',      models.FloatField(default=0.0)),
                ('prob_colon_aca',  models.FloatField(default=0.0)),
                ('prob_colon_n',    models.FloatField(default=0.0)),
                ('prob_lung_aca',   models.FloatField(default=0.0)),
                ('prob_lung_n',     models.FloatField(default=0.0)),
                ('prob_lung_scc',   models.FloatField(default=0.0)),
                ('notes',           models.TextField(blank=True, default='')),
                ('created_at',      models.DateTimeField(auto_now_add=True)),
            ],
            options={'db_table': 'app_predictionrecord', 'ordering': ['-created_at']},
        ),
    ]
