from django.db import models


class UserProfile(models.Model):
    name       = models.CharField(max_length=100)
    email      = models.EmailField(unique=True)
    password   = models.CharField(max_length=128)
    phone      = models.CharField(max_length=20, blank=True, default='')
    hospital   = models.CharField(max_length=200, blank=True, default='')
    role       = models.CharField(max_length=100, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'app_userprofile'


class PredictionRecord(models.Model):
    CANCER_TYPES = [
        ('colon_aca', 'Colon Adenocarcinoma'),
        ('colon_n',   'Colon Benign'),
        ('lung_aca',  'Lung Adenocarcinoma'),
        ('lung_n',    'Lung Benign'),
        ('lung_scc',  'Lung Squamous Cell Carcinoma'),
    ]
    user        = models.ForeignKey(UserProfile, on_delete=models.CASCADE,
                                    null=True, blank=True, related_name='predictions')
    image       = models.ImageField(upload_to='predictions/', null=True, blank=True)
    gradcam     = models.ImageField(upload_to='gradcam/',     null=True, blank=True)

    predicted_class  = models.CharField(max_length=50, choices=CANCER_TYPES, blank=True)
    confidence       = models.FloatField(default=0.0)

    # Store all 5 class probabilities as floats
    prob_colon_aca = models.FloatField(default=0.0)
    prob_colon_n   = models.FloatField(default=0.0)
    prob_lung_aca  = models.FloatField(default=0.0)
    prob_lung_n    = models.FloatField(default=0.0)
    prob_lung_scc  = models.FloatField(default=0.0)

    notes      = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def is_malignant(self):
        return self.predicted_class not in ['colon_n', 'lung_n']

    @property
    def label(self):
        mapping = {
            'colon_aca': 'Colon Adenocarcinoma',
            'colon_n':   'Colon Benign Tissue',
            'lung_aca':  'Lung Adenocarcinoma',
            'lung_n':    'Lung Benign Tissue',
            'lung_scc':  'Lung Squamous Cell Carcinoma',
        }
        return mapping.get(self.predicted_class, self.predicted_class)

    @property
    def probabilities_dict(self):
        return {
            'Colon Adenocarcinoma':        round(self.prob_colon_aca * 100, 2),
            'Colon Benign Tissue':         round(self.prob_colon_n   * 100, 2),
            'Lung Adenocarcinoma':         round(self.prob_lung_aca  * 100, 2),
            'Lung Benign Tissue':          round(self.prob_lung_n    * 100, 2),
            'Lung Squamous Cell Carcinoma':round(self.prob_lung_scc  * 100, 2),
        }

    def __str__(self):
        return f"{self.user} — {self.predicted_class} ({self.confidence:.1f}%)"

    class Meta:
        db_table = 'app_predictionrecord'
        ordering = ['-created_at']
