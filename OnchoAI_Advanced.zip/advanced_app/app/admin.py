from django.contrib import admin
from .models import UserProfile, PredictionRecord

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'hospital', 'role', 'created_at']

@admin.register(PredictionRecord)
class PredictionRecordAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'predicted_class', 'confidence', 'created_at']
    list_filter  = ['predicted_class']
