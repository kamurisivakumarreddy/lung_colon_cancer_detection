from django.urls import path
from . import views

urlpatterns = [
    path('',                        views.home,              name='home'),
    path('login/',                  views.login_view,        name='login'),
    path('register/',               views.register_view,     name='register'),
    path('logout/',                 views.logout_view,       name='logout'),
    path('dashboard/',              views.dashboard,         name='dashboard'),
    path('profile/',                views.profile_view,      name='profile'),
    path('predict/',                views.predict_view,      name='predict'),
    path('records/',                views.records_view,      name='records'),
    path('records/<int:pk>/',       views.prediction_detail, name='prediction_detail'),
    path('records/<int:pk>/pdf/',   views.download_pdf,      name='download_pdf'),
    path('records/<int:pk>/email/', views.email_report,      name='email_report'),
    path('records/export/excel/',   views.export_excel,      name='export_excel'),
    path('notebooks/',              views.notebook_view,     name='notebooks'),
]
