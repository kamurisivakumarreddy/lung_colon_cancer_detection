"""
OnchoAI — PDF Report Generator
Generates a professional patient prediction report.
"""
import os
import io
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image as RLImage
)
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.graphics import renderPDF


# ── Colour Palette ────────────────────────────────────────────────────
C_BG      = colors.HexColor('#07090f')
C_SURFACE = colors.HexColor('#111827')
C_ACCENT  = colors.HexColor('#00d4aa')
C_DANGER  = colors.HexColor('#f43f5e')
C_WARN    = colors.HexColor('#f59e0b')
C_TEXT    = colors.HexColor('#e2e8f0')
C_MUTED   = colors.HexColor('#64748b')
C_WHITE   = colors.white
C_GREEN   = colors.HexColor('#10b981')


def _style(name, **kw):
    s = ParagraphStyle(name, **kw)
    return s


def generate_report(prediction_record, output_path):
    """
    Generate PDF report for a PredictionRecord instance.
    Saves to output_path.
    """
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm,  bottomMargin=2*cm,
    )

    W, H = A4
    content_w = W - 4*cm
    story = []

    # ── Styles ────────────────────────────────────────────────────────
    title_style = _style('Title',
        fontName='Helvetica-Bold', fontSize=22,
        textColor=C_WHITE, spaceAfter=4,
        backColor=C_BG, leading=28
    )
    subtitle_style = _style('Sub',
        fontName='Helvetica', fontSize=11,
        textColor=C_ACCENT, spaceAfter=6
    )
    section_style = _style('Section',
        fontName='Helvetica-Bold', fontSize=12,
        textColor=C_ACCENT, spaceBefore=14, spaceAfter=6
    )
    body_style = _style('Body',
        fontName='Helvetica', fontSize=10,
        textColor=C_TEXT, leading=16
    )
    small_style = _style('Small',
        fontName='Helvetica', fontSize=9,
        textColor=C_MUTED, leading=13
    )
    verdict_style = _style('Verdict',
        fontName='Helvetica-Bold', fontSize=14,
        textColor=C_DANGER if prediction_record.is_malignant else C_GREEN,
        spaceBefore=8, spaceAfter=8
    )

    # ── Header Banner ─────────────────────────────────────────────────
    header_data = [[
        Paragraph('OnchoAI', _style('HBrand',
            fontName='Helvetica-Bold', fontSize=20, textColor=C_ACCENT)),
        Paragraph('Lung &amp; Colon Cancer Classifier<br/>'
                  '<font size=9 color="#64748b">Histopathological Image Analysis Report</font>',
                  _style('HTag', fontName='Helvetica', fontSize=11, textColor=C_WHITE,
                         alignment=2))
    ]]
    header_table = Table(header_data, colWidths=[content_w*0.5, content_w*0.5])
    header_table.setStyle(TableStyle([
        ('BACKGROUND',   (0,0), (-1,-1), C_SURFACE),
        ('ROUNDEDCORNERS', [8]),
        ('TOPPADDING',   (0,0), (-1,-1), 14),
        ('BOTTOMPADDING',(0,0), (-1,-1), 14),
        ('LEFTPADDING',  (0,0), (-1,-1), 16),
        ('RIGHTPADDING', (0,0), (-1,-1), 16),
        ('VALIGN',       (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width='100%', thickness=1, color=C_ACCENT, spaceAfter=12))

    # ── Report Meta ───────────────────────────────────────────────────
    user = prediction_record.user
    now  = prediction_record.created_at.strftime('%B %d, %Y  %H:%M') if prediction_record.created_at else datetime.now().strftime('%B %d, %Y  %H:%M')
    meta_data = [
        ['Report ID',  f'OAI-{prediction_record.id:06d}',
         'Date',       now],
        ['Analyst',    user.name if user else '—',
         'Hospital',   (user.hospital or '—') if user else '—'],
        ['Email',      (user.email or '—') if user else '—',
         'Role',       (user.role or '—') if user else '—'],
    ]
    meta_table = Table(meta_data, colWidths=[3*cm, 6*cm, 3*cm, content_w-12*cm])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND',   (0,0), (-1,-1), C_SURFACE),
        ('FONTNAME',     (0,0), (-1,-1), 'Helvetica'),
        ('FONTSIZE',     (0,0), (-1,-1), 9),
        ('TEXTCOLOR',    (0,0), (-1,-1), C_TEXT),
        ('FONTNAME',     (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME',     (2,0), (2,-1), 'Helvetica-Bold'),
        ('TEXTCOLOR',    (0,0), (0,-1), C_MUTED),
        ('TEXTCOLOR',    (2,0), (2,-1), C_MUTED),
        ('TOPPADDING',   (0,0), (-1,-1), 6),
        ('BOTTOMPADDING',(0,0), (-1,-1), 6),
        ('LEFTPADDING',  (0,0), (-1,-1), 10),
        ('GRID',         (0,0), (-1,-1), 0.3, colors.HexColor('#1e2d3d')),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 0.4*cm))

    # ── Prediction Result ─────────────────────────────────────────────
    story.append(Paragraph('Prediction Result', section_style))

    verdict_text = '⚠ MALIGNANT TISSUE DETECTED' if prediction_record.is_malignant else '✓ BENIGN TISSUE'
    v_color = C_DANGER if prediction_record.is_malignant else C_GREEN

    result_data = [
        ['Predicted Class',
         Paragraph(f'<b>{prediction_record.label}</b>',
                   _style('RC', fontName='Helvetica-Bold', fontSize=13, textColor=C_WHITE))],
        ['Confidence',
         Paragraph(f'<b>{prediction_record.confidence:.2f}%</b>',
                   _style('CC', fontName='Helvetica-Bold', fontSize=13, textColor=C_ACCENT))],
        ['Classification',
         Paragraph(f'<b>{verdict_text}</b>',
                   _style('VC', fontName='Helvetica-Bold', fontSize=13, textColor=v_color))],
    ]
    result_table = Table(result_data, colWidths=[4*cm, content_w - 4*cm])
    result_table.setStyle(TableStyle([
        ('BACKGROUND',   (0,0), (0,-1), colors.HexColor('#1a2332')),
        ('BACKGROUND',   (1,0), (1,-1), C_SURFACE),
        ('TEXTCOLOR',    (0,0), (0,-1), C_MUTED),
        ('FONTNAME',     (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTSIZE',     (0,0), (0,-1), 9),
        ('TOPPADDING',   (0,0), (-1,-1), 10),
        ('BOTTOMPADDING',(0,0), (-1,-1), 10),
        ('LEFTPADDING',  (0,0), (-1,-1), 14),
        ('GRID',         (0,0), (-1,-1), 0.3, colors.HexColor('#1e2d3d')),
    ]))
    story.append(result_table)
    story.append(Spacer(1, 0.4*cm))

    # ── Probability Table ─────────────────────────────────────────────
    story.append(Paragraph('Class Probability Breakdown', section_style))

    prob_headers = [['Class', 'Probability', 'Bar']]
    probs = prediction_record.probabilities_dict
    prob_rows = []
    for cls_name, pct in sorted(probs.items(), key=lambda x: -x[1]):
        bar_w = max(int(pct * 2.5), 2)
        is_top = cls_name == prediction_record.label
        bar_color = C_ACCENT if is_top else C_MUTED
        bar_str   = '█' * bar_w
        prob_rows.append([
            Paragraph(f'{"<b>" if is_top else ""}{cls_name}{"</b>" if is_top else ""}',
                       _style('PR', fontName='Helvetica', fontSize=9,
                              textColor=C_WHITE if is_top else C_TEXT)),
            Paragraph(f'{"<b>" if is_top else ""}{pct:.2f}%{"</b>" if is_top else ""}',
                       _style('PV', fontName='Helvetica-Bold' if is_top else 'Helvetica',
                              fontSize=9,
                              textColor=C_ACCENT if is_top else C_TEXT)),
            Paragraph(f'<font color="{"#00d4aa" if is_top else "#334155"}">{bar_str}</font>',
                       _style('PB', fontName='Helvetica', fontSize=7)),
        ])

    prob_table = Table(prob_headers + prob_rows,
                       colWidths=[6*cm, 3*cm, content_w - 9*cm])
    prob_table.setStyle(TableStyle([
        ('BACKGROUND',   (0,0), (-1,0), colors.HexColor('#1a2332')),
        ('BACKGROUND',   (0,1), (-1,-1), C_SURFACE),
        ('TEXTCOLOR',    (0,0), (-1,0), C_MUTED),
        ('FONTNAME',     (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE',     (0,0), (-1,0), 8),
        ('TOPPADDING',   (0,0), (-1,-1), 7),
        ('BOTTOMPADDING',(0,0), (-1,-1), 7),
        ('LEFTPADDING',  (0,0), (-1,-1), 12),
        ('GRID',         (0,0), (-1,-1), 0.3, colors.HexColor('#1e2d3d')),
        ('ROWBACKGROUNDS', (0,1), (-1,-1),
         [C_SURFACE, colors.HexColor('#0d1117')]),
    ]))
    story.append(prob_table)
    story.append(Spacer(1, 0.4*cm))

    # ── Images: Original + Grad-CAM ───────────────────────────────────
    from django.conf import settings as django_settings

    img_cells = []
    if prediction_record.image:
        img_path = os.path.join(django_settings.MEDIA_ROOT,
                                str(prediction_record.image))
        if os.path.exists(img_path):
            img_cells.append([
                Paragraph('Input Image', _style('IL', fontName='Helvetica-Bold',
                           fontSize=9, textColor=C_MUTED)),
                RLImage(img_path, width=6*cm, height=6*cm)
            ])

    if prediction_record.gradcam:
        gc_path = os.path.join(django_settings.MEDIA_ROOT,
                               str(prediction_record.gradcam))
        if os.path.exists(gc_path):
            img_cells.append([
                Paragraph('Grad-CAM Heatmap', _style('IL2', fontName='Helvetica-Bold',
                           fontSize=9, textColor=C_MUTED)),
                RLImage(gc_path, width=6*cm, height=6*cm)
            ])

    if img_cells:
        story.append(Paragraph('Image Analysis', section_style))
        flat = []
        labels_row = []
        imgs_row   = []
        for label_p, img_p in img_cells:
            labels_row.append(label_p)
            imgs_row.append(img_p)
        img_table = Table([labels_row, imgs_row],
                          colWidths=[content_w / len(img_cells)] * len(img_cells))
        img_table.setStyle(TableStyle([
            ('BACKGROUND',   (0,0), (-1,-1), C_SURFACE),
            ('ALIGN',        (0,0), (-1,-1), 'CENTER'),
            ('TOPPADDING',   (0,0), (-1,-1), 10),
            ('BOTTOMPADDING',(0,0), (-1,-1), 10),
            ('GRID',         (0,0), (-1,-1), 0.3, colors.HexColor('#1e2d3d')),
        ]))
        story.append(img_table)
        story.append(Spacer(1, 0.4*cm))

    # ── Notes ─────────────────────────────────────────────────────────
    if prediction_record.notes:
        story.append(Paragraph('Clinical Notes', section_style))
        story.append(Paragraph(prediction_record.notes, body_style))
        story.append(Spacer(1, 0.3*cm))

    # ── Disclaimer ────────────────────────────────────────────────────
    story.append(HRFlowable(width='100%', thickness=0.5, color=C_MUTED, spaceBefore=10))
    story.append(Paragraph(
        '<b>Disclaimer:</b> This report is generated by an AI classification system for '
        'research and educational purposes only. It is not a substitute for professional '
        'medical diagnosis. Always consult a licensed pathologist or oncologist for '
        'clinical decisions.',
        _style('Disc', fontName='Helvetica', fontSize=8, textColor=C_MUTED, leading=12)
    ))

    doc.build(story)
    return output_path
