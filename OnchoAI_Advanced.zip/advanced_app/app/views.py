import os
import json
import uuid
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import HttpResponse, JsonResponse, FileResponse
from django.conf import settings
from django.core.mail import EmailMessage
from django.views.decorators.http import require_POST

from .models import UserProfile, PredictionRecord
from .ai_engine import predict, generate_gradcam, CLASS_NAMES, CLASS_LABELS
from .pdf_report import generate_report


# ──────────────────────────────────────────────────────────────────────
# Auth helpers
# ──────────────────────────────────────────────────────────────────────
def _get_user(request):
    uid = request.session.get('user_id')
    if uid:
        try:
            return UserProfile.objects.get(pk=uid)
        except UserProfile.DoesNotExist:
            pass
    return None


def login_required_view(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(request, *args, **kwargs):
        if not _get_user(request):
            return redirect('login')
        return fn(request, *args, **kwargs)
    return wrapper


# ──────────────────────────────────────────────────────────────────────
# Public pages
# ──────────────────────────────────────────────────────────────────────
def home(request):
    return render(request, 'app/home.html')


def login_view(request):
    if request.method == 'POST':
        email    = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        try:
            user = UserProfile.objects.get(email=email, password=password)
            request.session['user_id']   = user.pk
            request.session['user_name'] = user.name
            return redirect('dashboard')
        except UserProfile.DoesNotExist:
            messages.error(request, 'Invalid email or password.')
    return render(request, 'app/login.html')


def register_view(request):
    if request.method == 'POST':
        name     = request.POST.get('name', '').strip()
        email    = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        hospital = request.POST.get('hospital', '').strip()
        role     = request.POST.get('role', '').strip()
        phone    = request.POST.get('phone', '').strip()

        if UserProfile.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered.')
        else:
            UserProfile.objects.create(
                name=name, email=email, password=password,
                hospital=hospital, role=role, phone=phone
            )
            messages.success(request, 'Account created! Please log in.')
            return redirect('login')
    return render(request, 'app/register.html')


def logout_view(request):
    request.session.flush()
    return redirect('home')


# ──────────────────────────────────────────────────────────────────────
# Dashboard
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def dashboard(request):
    user  = _get_user(request)
    preds = PredictionRecord.objects.filter(user=user).order_by('-created_at')

    # Stats
    total       = preds.count()
    malignant   = sum(1 for p in preds if p.is_malignant)
    benign      = total - malignant
    avg_conf    = round(sum(p.confidence for p in preds) / total, 1) if total else 0

    # Class distribution
    class_counts = {}
    for p in preds:
        class_counts[p.predicted_class] = class_counts.get(p.predicted_class, 0) + 1

    # Monthly trend (last 6 months)
    from collections import defaultdict
    monthly = defaultdict(int)
    for p in preds:
        key = p.created_at.strftime('%b %Y')
        monthly[key] += 1

    recent = preds[:8]

    return render(request, 'app/dashboard.html', {
        'user':         user,
        'total':        total,
        'malignant':    malignant,
        'benign':       benign,
        'avg_conf':     avg_conf,
        'recent':       recent,
        'class_counts': json.dumps(class_counts),
        'monthly':      json.dumps(dict(list(monthly.items())[-6:])),
    })


# ──────────────────────────────────────────────────────────────────────
# Profile
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def profile_view(request):
    user = _get_user(request)
    if request.method == 'POST':
        user.name     = request.POST.get('name', user.name).strip()
        user.hospital = request.POST.get('hospital', '').strip()
        user.role     = request.POST.get('role', '').strip()
        user.phone    = request.POST.get('phone', '').strip()
        user.save()
        request.session['user_name'] = user.name
        messages.success(request, 'Profile updated successfully.')
        return redirect('profile')
    return render(request, 'app/profile.html', {'user': user})


# ──────────────────────────────────────────────────────────────────────
# Predict
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def predict_view(request):
    user   = _get_user(request)
    result = None

    if request.method == 'POST':
        image_file = request.FILES.get('image')
        notes      = request.POST.get('notes', '').strip()

        if not image_file:
            messages.error(request, 'Please upload an image.')
            return render(request, 'app/predict.html', {'result': None})

        # Save uploaded image temporarily to run prediction
        tmp_dir  = os.path.join(settings.MEDIA_ROOT, 'tmp')
        os.makedirs(tmp_dir, exist_ok=True)
        tmp_name = f"tmp_{uuid.uuid4().hex[:8]}{os.path.splitext(image_file.name)[1]}"
        tmp_path = os.path.join(tmp_dir, tmp_name)

        with open(tmp_path, 'wb') as f:
            for chunk in image_file.chunks():
                f.write(chunk)

        # Run prediction
        pred_result = predict(tmp_path)
        probs       = pred_result['probabilities']  # list of 5 floats

        # Save record
        record = PredictionRecord(
            user            = user,
            predicted_class = pred_result['predicted_class'],
            confidence      = pred_result['confidence'],
            prob_colon_aca  = probs[0],
            prob_colon_n    = probs[1],
            prob_lung_aca   = probs[2],
            prob_lung_n     = probs[3],
            prob_lung_scc   = probs[4],
            notes           = notes,
        )
        # Re-open file for Django ImageField save
        image_file.seek(0)
        record.image.save(image_file.name, image_file, save=False)
        record.save()

        # Grad-CAM
        pred_index = CLASS_NAMES.index(pred_result['predicted_class'])
        gradcam_dir  = os.path.join(settings.MEDIA_ROOT, 'gradcam')
        gradcam_fname = generate_gradcam(tmp_path, pred_index, gradcam_dir)
        if gradcam_fname:
            record.gradcam = f'gradcam/{gradcam_fname}'
            record.save(update_fields=['gradcam'])

        # Clean up temp file
        try:
            os.remove(tmp_path)
        except Exception:
            pass

        result = {
            'record':          record,
            'predicted_class': pred_result['predicted_class'],
            'label':           CLASS_LABELS[pred_result['predicted_class']],
            'confidence':      pred_result['confidence'],
            'probabilities':   record.probabilities_dict,
            'is_malignant':    record.is_malignant,
            'using_real_model': pred_result['using_real_model'],
            'gradcam_url':     record.gradcam.url if record.gradcam else None,
        }

    class_list = list(CLASS_LABELS.items())
    return render(request, 'app/predict.html', {'result': result, 'class_list': class_list})


# ──────────────────────────────────────────────────────────────────────
# Records
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def records_view(request):
    user   = _get_user(request)
    filter_class = request.GET.get('class', '')
    filter_type  = request.GET.get('type', '')

    preds = PredictionRecord.objects.filter(user=user).order_by('-created_at')

    if filter_class:
        preds = preds.filter(predicted_class=filter_class)
    if filter_type == 'malignant':
        preds = preds.exclude(predicted_class__in=['colon_n', 'lung_n'])
    elif filter_type == 'benign':
        preds = preds.filter(predicted_class__in=['colon_n', 'lung_n'])

    return render(request, 'app/records.html', {
        'preds':        preds,
        'filter_class': filter_class,
        'filter_type':  filter_type,
        'class_names':  CLASS_NAMES,
    })


# ──────────────────────────────────────────────────────────────────────
# Single prediction detail
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def prediction_detail(request, pk):
    user   = _get_user(request)
    record = get_object_or_404(PredictionRecord, pk=pk, user=user)
    return render(request, 'app/prediction_detail.html', {'record': record})


# ──────────────────────────────────────────────────────────────────────
# PDF Report Download
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def download_pdf(request, pk):
    user   = _get_user(request)
    record = get_object_or_404(PredictionRecord, pk=pk, user=user)

    reports_dir = os.path.join(settings.MEDIA_ROOT, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    pdf_path = os.path.join(reports_dir, f'report_{record.pk}.pdf')

    generate_report(record, pdf_path)

    response = FileResponse(
        open(pdf_path, 'rb'),
        content_type='application/pdf'
    )
    response['Content-Disposition'] = f'attachment; filename="OnchoAI_Report_{record.pk}.pdf"'
    return response


# ──────────────────────────────────────────────────────────────────────
# Email Report
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def email_report(request, pk):
    user   = _get_user(request)
    record = get_object_or_404(PredictionRecord, pk=pk, user=user)

    if not settings.EMAIL_HOST_USER:
        messages.error(request, 'Email is not configured. Please set EMAIL_HOST_USER in settings.py.')
        return redirect('prediction_detail', pk=pk)

    reports_dir = os.path.join(settings.MEDIA_ROOT, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    pdf_path = os.path.join(reports_dir, f'report_{record.pk}.pdf')
    generate_report(record, pdf_path)

    try:
        mail = EmailMessage(
            subject=f'OnchoAI Report — {record.label} (ID: {record.pk})',
            body=(
                f'Dear {user.name},\n\n'
                f'Please find attached your OnchoAI prediction report.\n\n'
                f'Prediction : {record.label}\n'
                f'Confidence : {record.confidence:.2f}%\n'
                f'Date       : {record.created_at.strftime("%B %d, %Y")}\n\n'
                f'Disclaimer: This is an AI-generated report for research purposes only.\n\n'
                f'— OnchoAI Team'
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
        )
        mail.attach_file(pdf_path)
        mail.send()
        messages.success(request, f'Report emailed to {user.email}.')
    except Exception as e:
        messages.error(request, f'Failed to send email: {e}')

    return redirect('prediction_detail', pk=pk)


# ──────────────────────────────────────────────────────────────────────
# Excel Export
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def export_excel(request):
    user  = _get_user(request)
    preds = PredictionRecord.objects.filter(user=user).order_by('-created_at')

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Predictions'

    # Header styling
    header_fill = PatternFill('solid', fgColor='111827')
    header_font = Font(bold=True, color='00d4aa', size=11)
    headers = [
        'ID', 'Date', 'Predicted Class', 'Label', 'Confidence (%)',
        'Is Malignant',
        'Colon ACA (%)', 'Colon Benign (%)',
        'Lung ACA (%)',  'Lung Benign (%)', 'Lung SCC (%)',
        'Notes'
    ]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = Alignment(horizontal='center')

    # Data rows
    for row_idx, p in enumerate(preds, 2):
        ws.cell(row=row_idx, column=1,  value=p.pk)
        ws.cell(row=row_idx, column=2,  value=p.created_at.strftime('%Y-%m-%d %H:%M') if p.created_at else '')
        ws.cell(row=row_idx, column=3,  value=p.predicted_class)
        ws.cell(row=row_idx, column=4,  value=p.label)
        ws.cell(row=row_idx, column=5,  value=round(p.confidence, 2))
        ws.cell(row=row_idx, column=6,  value='Yes' if p.is_malignant else 'No')
        ws.cell(row=row_idx, column=7,  value=round(p.prob_colon_aca * 100, 2))
        ws.cell(row=row_idx, column=8,  value=round(p.prob_colon_n   * 100, 2))
        ws.cell(row=row_idx, column=9,  value=round(p.prob_lung_aca  * 100, 2))
        ws.cell(row=row_idx, column=10, value=round(p.prob_lung_n    * 100, 2))
        ws.cell(row=row_idx, column=11, value=round(p.prob_lung_scc  * 100, 2))
        ws.cell(row=row_idx, column=12, value=p.notes)

        # Alternate row color
        fill_color = 'F8FAFC' if row_idx % 2 == 0 else 'FFFFFF'
        for col in range(1, 13):
            ws.cell(row=row_idx, column=col).fill = PatternFill('solid', fgColor=fill_color)

    # Column widths
    widths = [6, 18, 15, 28, 16, 13, 14, 15, 14, 14, 12, 30]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="OnchoAI_Records.xlsx"'
    wb.save(response)
    return response


# ──────────────────────────────────────────────────────────────────────
# Notebooks page
# ──────────────────────────────────────────────────────────────────────
@login_required_view
def notebook_view(request):
    eda_steps = [
        'Class Distribution', 'Sample Images', 'Augmentation Preview',
        'Colour Stats', 't-SNE Plot', 'Pixel Distribution',
        'Aspect Ratios', 'Channel Histograms', 'Correlation Matrix', 'Class Balance'
    ]
    model_steps = [
        'GPU Check', 'Imports', 'Mount Drive', 'Configuration',
        'Data Loading & Augmentation', 'Build Combined Model', 'Callbacks',
        'Phase 1 Training (Frozen)', 'Phase 2 Fine-Tuning', 'Training History Plot',
        'Validation Evaluation', 'Confusion Matrix', 'Precision / Recall / F1',
        'ROC Curves', 'Confidence Distribution', 'Grad-CAM Heatmaps',
        'Save Final Model', 'Single Image Inference', 'Results Summary'
    ]
    return render(request, 'app/notebooks.html', {
        'eda_steps': eda_steps,
        'model_steps': model_steps,
    })
